package com.microservices.kafkaproduces;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProducesApplicationTests {

	@Test
	void contextLoads() {
	}

}
