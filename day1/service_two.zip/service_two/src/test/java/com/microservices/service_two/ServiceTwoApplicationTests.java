package com.microservices.service_two;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
